#!/bin/bash
###############################################
#
#	Arrancador de la practica
#
#	1º crea los directorios
#	2º crea los ficheros de ejecucion
#	3º extrae los ficheros jar
#	4º ejecuta los jar
###############################################
#
#	Parametros $1 es la opcion:
# 	instalacion y ejecucion = 1
#	ejecucion de servidor y base de base de datos = 2
#	ejecucion de usuario = 3
#	instruciones sin parametros
#
###############################################

OPCION=$1
FECHA=`date +%Y%m%d`
HORA=`date +%H%M`
LOG=/tmp/logArrancador${FECHA}_${HORA}.txt


if [ $# -eq "0" ]
then
	echo -e "instalacion y ejecucion: ejecutar con arrancador.sh 1 asume que todos los servicios se arrancan desde localhost\n"
	echo -e "ejecucion de base de datos: arrancador.sh 2 si no tiene parametros asume que esta arrancado en localhost se puede arrancar con la ip como parametro $2\n"
	echo -e "ejecucion de servidor: ejecutar con arrancador.sh 3 si no tiene parametros asume que esta arrancado en localhost se puede arrancar con parametros de ip tal que \$2 = ip de la base de datos a la que se debe conectar \$3 = ip de propio servidor\n"
	echo -e "ejecucion de servidor y base de datos: ejecutar con arrancador.sh 4 se le pueden pasar los parametros de ip tal que \$2 = ip de la base de datos \$3 ip del servidor\n"
	echo -e "ejecucion de usuario: ejecutar con arrancador.sh 5 se puede pasar como parametro la ip del servidor al que se debe conectar como $2 = ip de servidor\n"
fi

if [ -e ${HOME}/sistemasDistribuidos.zip ] 
then
	echo "existe el fichero con los jar" > ${LOG}
else
	echo "no existe el fichero con los jar" > ${LOG}
	exit 1
fi



if [ "${OPCION}" == "1" ]
then
	IP1=$2 #ip de la base de datos
	IP2=$3 #ip del servidor
	echo -e "crea los directorios en /home/usuario/ \n" >> ${LOG}

	if [ -d ${HOME}/practica/ ] 
	then 
		echo -e "existe la HOME practica en el home del usuario actual \n" >> ${LOG}
	else
		mkdir -p ${HOME}/practica/
		echo -e "HOME practica creada \n" >> ${LOG}
	fi

	echo -e "comprueba si existe el fichero de lista.txt \n" >> ${LOG}

	if [ -e ${HOME}/practica/lista.txt ]
	then
		echo -e "existe el archivo lista.txt en la que iran los usuarios  como un hashmap \n" >> ${LOG}
	else
		touch ${HOME}/practica/lista.txt
		echo -e "creado el archivo de lista.txt \n" >> ${LOG}
	fi

	echo -e "comprueba si existe el unzip en /usr/bin/unzip " >> ${LOG}

	if [ -e /usr/bin/unzip ] 
	then
		/usr/bin/unzip ${HOME}/sistemasDistribuidos.zip -d ${HOME}/practica/
		chmod u+x ${HOME}/practica/*
		echo -e "practica descomprimida\n" >> ${LOG}
	else
		echo -e "descomprimir manualmente\n" >> ${LOG}
		exit 2
	fi

	echo -e "arrancador de los java" >> ${LOG}

	echo -e "arrancador de base de datos\n" >> ${LOG}
	java -jar ${HOME}/practica/basedeDatos.jar & 
	sleep 10
	echo -e "arrancador de servidor\n" >> ${LOG}
	java -jar ${HOME}/practica/servidor.jar &
	sleep 10 
	echo -e "arrancador de gui \n" >> ${LOG}
	java -jar ${HOME}/practica/usuario.jar &
	exit 0
else
	if [ "${OPCION}" == "2" ]
	then
		echo -e "arranca solo base de datos \n" >> ${LOG}
		java -jar ${HOME}/practica/basedeDatos.jar ${IP1}& 
		sleep 10
		exit 0
	else
		if [ "${OPCION}" == "3" ]
		then
			echo -e "arrancador de servidor\n" >> ${LOG}
			java -jar ${HOME}/practica/servidor.jar ${IP1} ${IP2}&
			sleep 10
			exit 0
		else
		if [ "${OPCION}" == "4" ]
		then
			IP1=$2 #ip de la base de datos
			IP2=$3 #ip del servidor
			echo -e "arranca base de datos \n" > ${LOG}
			java -jar ${HOME}/practica/basedeDatos.jar ${IP1}& 
			sleep 10
			echo -e "arrancador de servidor\n" >> ${LOG}
			java -jar ${HOME}/practica/servidor.jar ${IP1} ${IP2}&
			sleep 10
			exit 0
		else 
			if [ "${OPCION}" == "5" ]	
			then
				IP1=$2 #ip del servidor
				echo -e "arrancador de gui \n" > ${LOG}
				java -jar ${HOME}/practica/usuario.jar ${IP1}&
				exit 0
			fi
		fi
	fi
	fi
fi
